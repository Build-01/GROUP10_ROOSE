ROOSE Hotel Reservation System — Windows x64

QUICK START
1. Extract the ZIP to a folder.
2. Run RooseHotel.App.exe.
3. On first launch, create the initial staff account. There is no default username or password.
4. Sign in and use the left navigation for rooms, guests, reservations, billing, and check-in/check-out.

REQUIREMENT
Windows x64 with the .NET 9 Desktop Runtime installed. This is a framework-dependent Release build; it does not include the .NET runtime.

DATA
The app creates its local SQLite database at %LOCALAPPDATA%\RooseHotel\roosehotel.db. Back up that file if you need to preserve local records.

VERIFICATION
Release publish completed successfully. The test suite passed 12/12 and the full solution built with 0 warnings and 0 errors.
