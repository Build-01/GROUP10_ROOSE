ROOSE Hotel Reservation System — Windows x64

QUICK START
1. Extract the ZIP to a folder.
2. Run RooseHotel.App.exe.
3. On first launch, create the initial staff account. There is no default username or password.
4. Sign in. Dashboard figures reload from saved SQLite records whenever the dashboard opens; press Refresh to reload while it is open.

REQUIREMENT
Windows x64 with the .NET 9 Desktop Runtime installed. This is a framework-dependent Release build; it does not include the .NET runtime.

DATA
The app creates its local SQLite database at %LOCALAPPDATA%\RooseHotel\roosehotel.db. Back up that file if you need to preserve local records.
